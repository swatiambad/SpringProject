package apiTesting;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class TestAPI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Response response = RestAssured.get("http://localhost:9090/citylist");
		Response response1 = RestAssured.get("https://samples.openweathermap.org/data/2.5/weather?q=London,uk&appid=b6907d289e10d714a6e88b30761fae22");
		
		System.out.println(response.asString());
		System.out.println(response1.asString());
	}

}
