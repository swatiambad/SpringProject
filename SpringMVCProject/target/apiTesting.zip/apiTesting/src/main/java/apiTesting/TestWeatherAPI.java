package apiTesting;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class TestWeatherAPI {
	String apiURL = "https://samples.openweathermap.org/data/2.5/weather?q=London,uk&appid=b6907d289e10d714a6e88b30761fae22";
	Response response = RestAssured.get(apiURL);
	
	@Test
	public void testResponseCode() {
		
		int ResCode = response.getStatusCode();
		System.out.println(ResCode);
		Assert.assertEquals(ResCode, 200);
		
	}
	
	@Test
	public void testBody()
	{
		Long time = response.getTime();
		System.out.println("Response time :" + time);
		System.out.println(response.asString());
	}
	
	/*@Test
	public void testHeader(){
		System.out.println(response.getHeader(apiURL));
	}*/
	
	
}
